#!/system/bin/sh

MODDIR="${0%/*}"
[ -f "$MODDIR/module.prop" ] || MODDIR=/data/adb/modules/spacewar-daily-profile

LOG="$MODDIR/module.log"
DIAGNOSTICS="$MODDIR/diagnostics.txt"
STOPFILE="$MODDIR/STOP"
LAST_CPU_STATE="$MODDIR/last_cpu_state"
LAST_ACTIVITY_STATE="$MODDIR/last_activity_state"

LPM_TARGET=/sys/module/lpm_levels/parameters/sleep_disabled
CPU_POLICY=/sys/devices/system/cpu/cpufreq/policy0
CPU_TARGET=300000
GMS_PACKAGE=com.google.android.gms
ACTIVITY_OP=ACTIVITY_RECOGNITION

ORIGINAL_LPM="$MODDIR/original_sleep_disabled"
ORIGINAL_MOBILE_DATA="$MODDIR/original_mobile_data_always_on"
ORIGINAL_CPU_MIN="$MODDIR/original_scaling_min_freq"
ORIGINAL_ACTIVITY_PACKAGE="$MODDIR/original_activity_package_appop"
ORIGINAL_ACTIVITY_UID="$MODDIR/original_activity_uid_appop"
ORIGINAL_DOZE_CONSTANTS="$MODDIR/original_device_idle_constants"
ORIGINAL_BLUETOOTH_SCAN_TIMEOUT="$MODDIR/original_bluetooth_scan_timeout"
DOZE_ABSENT=__ABSENT__
DOZE_NOTIFICATION_SAFE='inactive_to=1800000,sensing_to=240000,locating_to=30000,motion_inactive_to=600000,idle_after_inactive_to=1800000'
BLUETOOTH_CONFIG_ABSENT=__ABSENT__
BLUETOOTH_SCAN_TIMEOUT_TARGET=120000

log_message() {
    printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG"
}

read_one_line() {
    [ -r "$1" ] || return 1
    tr -d '\r\n' < "$1" 2>/dev/null
}

valid_lpm_value() {
    case "$1" in Y|y|N|n|0|1) return 0 ;; esac
    return 1
}

valid_binary_value() {
    case "$1" in 0|1) return 0 ;; esac
    return 1
}

valid_frequency() {
    case "$1" in
        ''|*[!0-9]*) return 1 ;;
        *) [ "$1" -ge 100000 ] && [ "$1" -le 4000000 ] ;;
    esac
}

valid_scan_timeout() {
    case "$1" in
        ''|*[!0-9]*) return 1 ;;
        *) [ "$1" -ge 60000 ] && [ "$1" -le 600000 ] ;;
    esac
}

is_user_unlocked() {
    [ "$(am get-started-user-state 0 2>/dev/null | tr -d '\r\n ')" = RUNNING_UNLOCKED ]
}

valid_appop_mode() {
    case "$1" in allow|ignore|foreground|default|deny|ask) return 0 ;; esac
    return 1
}

import_file_if_valid() {
    source_file="$1"
    destination_file="$2"
    validator="$3"

    [ -s "$destination_file" ] && return 0
    [ -s "$source_file" ] || return 1
    value=$(read_one_line "$source_file")
    "$validator" "$value" || return 1
    printf '%s\n' "$value" > "$destination_file"
    log_message "Imported baseline $(basename "$destination_file")=$value from $source_file"
}

read_package_appop() {
    line=$(cmd appops get --user 0 "$GMS_PACKAGE" "$ACTIVITY_OP" 2>/dev/null | grep "^$ACTIVITY_OP:" | head -n 1)
    mode=$(printf '%s\n' "$line" | sed -n 's/.*: \([a-z_]*\).*/\1/p')
    valid_appop_mode "$mode" && printf '%s\n' "$mode"
}

read_uid_appop() {
    line=$(cmd appops get --user 0 "$GMS_PACKAGE" "$ACTIVITY_OP" 2>/dev/null | grep '^Uid mode:' | head -n 1)
    mode=$(printf '%s\n' "$line" | sed -n 's/.*: \([a-z_]*\).*/\1/p')
    if valid_appop_mode "$mode"; then
        printf '%s\n' "$mode"
    else
        read_package_appop
    fi
}

save_baselines() {
    import_file_if_valid /data/adb/modules/spacewar-lpm-restore/original_sleep_disabled "$ORIGINAL_LPM" valid_lpm_value
    if [ ! -s "$ORIGINAL_LPM" ]; then
        value=$(read_one_line "$LPM_TARGET")
        valid_lpm_value "$value" && printf '%s\n' "$value" > "$ORIGINAL_LPM"
    fi

    import_file_if_valid /data/adb/modules/spacewar-lpm-restore/original_mobile_data_always_on "$ORIGINAL_MOBILE_DATA" valid_binary_value
    if [ ! -s "$ORIGINAL_MOBILE_DATA" ]; then
        value=$(settings get global mobile_data_always_on 2>/dev/null | tr -d '\r\n')
        valid_binary_value "$value" && printf '%s\n' "$value" > "$ORIGINAL_MOBILE_DATA"
    fi

    import_file_if_valid /data/adb/modules/spacewar-cpu-idle-profile/original_scaling_min_freq "$ORIGINAL_CPU_MIN" valid_frequency
    if [ ! -s "$ORIGINAL_CPU_MIN" ]; then
        value=$(read_one_line "$CPU_POLICY/scaling_min_freq")
        if [ "$value" = "$CPU_TARGET" ]; then value=691200; fi
        valid_frequency "$value" && printf '%s\n' "$value" > "$ORIGINAL_CPU_MIN"
    fi

    import_file_if_valid /data/adb/modules/spacewar-screenoff-activity-guard/original_appops "$ORIGINAL_ACTIVITY_PACKAGE" valid_appop_mode
    if [ ! -s "$ORIGINAL_ACTIVITY_PACKAGE" ]; then
        value=$(read_package_appop)
        valid_appop_mode "$value" && printf '%s\n' "$value" > "$ORIGINAL_ACTIVITY_PACKAGE"
    fi

    import_file_if_valid /data/adb/modules/spacewar-screenoff-activity-guard/original_uid_appop "$ORIGINAL_ACTIVITY_UID" valid_appop_mode
    if [ ! -s "$ORIGINAL_ACTIVITY_UID" ]; then
        value=$(read_uid_appop)
        valid_appop_mode "$value" && printf '%s\n' "$value" > "$ORIGINAL_ACTIVITY_UID"
    fi

    if [ ! -s "$ORIGINAL_DOZE_CONSTANTS" ]; then
        value=$(settings get global device_idle_constants 2>/dev/null | tr -d '\r\n')
        if [ -z "$value" ] || [ "$value" = null ]; then value="$DOZE_ABSENT"; fi
        printf '%s\n' "$value" > "$ORIGINAL_DOZE_CONSTANTS"
        log_message "Saved device_idle_constants baseline=$value"
    fi

    if [ ! -s "$ORIGINAL_BLUETOOTH_SCAN_TIMEOUT" ]; then
        value=$(device_config get bluetooth scan_timeout_millis 2>/dev/null | tr -d '\r\n')
        if [ -z "$value" ] || [ "$value" = null ]; then value="$BLUETOOTH_CONFIG_ABSENT"; fi
        if [ "$value" = "$BLUETOOTH_SCAN_TIMEOUT_TARGET" ]; then value=300000; fi
        if [ "$value" = "$BLUETOOTH_CONFIG_ABSENT" ] || valid_scan_timeout "$value"; then
            printf '%s\n' "$value" > "$ORIGINAL_BLUETOOTH_SCAN_TIMEOUT"
            log_message "Saved Bluetooth scan-timeout baseline=$value"
        fi
    fi

}

apply_static_profile() {
    current=$(read_one_line "$LPM_TARGET")
    if valid_lpm_value "$current"; then
        case "$current" in
            N|n|0) ;;
            *)
                if printf 'N\n' > "$LPM_TARGET" 2>/dev/null; then
                    log_message "Qualcomm LPM enabled: sleep_disabled $current -> $(read_one_line "$LPM_TARGET")"
                else
                    log_message "WARNING: unable to enable Qualcomm LPM."
                fi
                ;;
        esac
    else
        log_message "WARNING: unknown Qualcomm LPM value '$current'; unchanged."
    fi

    current=$(settings get global mobile_data_always_on 2>/dev/null | tr -d '\r\n')
    if [ "$current" = 1 ]; then
        settings put global mobile_data_always_on 0 2>/dev/null
        log_message "Radio idle enabled: mobile_data_always_on 1 -> $(settings get global mobile_data_always_on 2>/dev/null)"
    elif [ "$current" != 0 ]; then
        log_message "WARNING: unknown mobile_data_always_on value '$current'; unchanged."
    fi

    current=$(settings get global device_idle_constants 2>/dev/null | tr -d '\r\n')
    if [ "$current" != "$DOZE_NOTIFICATION_SAFE" ]; then
        settings put global device_idle_constants "$DOZE_NOTIFICATION_SAFE" 2>/dev/null
        after=$(settings get global device_idle_constants 2>/dev/null | tr -d '\r\n')
        if [ "$after" = "$DOZE_NOTIFICATION_SAFE" ]; then
            log_message "Applied notification-safe AOSP deep-Doze timings."
        else
            log_message "WARNING: failed to apply notification-safe deep-Doze timings; readback=$after"
        fi
    fi

    apply_bluetooth_scan_timeout
}

apply_bluetooth_scan_timeout() {
    current=$(device_config get bluetooth scan_timeout_millis 2>/dev/null | tr -d '\r\n')
    if [ "$current" != "$BLUETOOTH_SCAN_TIMEOUT_TARGET" ]; then
        device_config put bluetooth scan_timeout_millis "$BLUETOOTH_SCAN_TIMEOUT_TARGET" >/dev/null 2>&1
        after=$(device_config get bluetooth scan_timeout_millis 2>/dev/null | tr -d '\r\n')
        if [ "$after" = "$BLUETOOTH_SCAN_TIMEOUT_TARGET" ]; then
            log_message "Framework high-power BLE scan timeout $current -> ${BLUETOOTH_SCAN_TIMEOUT_TARGET}ms"
        else
            log_message "WARNING: failed to apply Bluetooth scan timeout; readback=$after"
        fi
    fi
}

is_charging_sysfs() {
    for node in /sys/class/power_supply/usb/online /sys/class/power_supply/ac/online /sys/class/power_supply/dc/online /sys/class/power_supply/wireless/online; do
        [ -r "$node" ] && [ "$(read_one_line "$node")" = 1 ] && return 0
    done
    status=$(read_one_line /sys/class/power_supply/battery/status)
    [ "$status" = Charging ] || [ "$status" = Full ]
}

is_screen_on() {
    # SurfaceFlinger's tracing property follows Android display-state values
    # on this ROM (1=OFF, 2=ON, 3/4=DOZE). Reading it is substantially cheaper
    # than starting a full PowerManager dumpsys every profile cycle.
    display_state=$(getprop debug.tracing.screen_state 2>/dev/null | tr -d '\r\n')
    case "$display_state" in
        2|5|6) return 0 ;;
        1|3|4) return 1 ;;
    esac

    # Compatibility fallback for builds without the tracing property or with
    # an unknown future display state.
    dumpsys power 2>/dev/null | grep -q 'mWakefulness=Awake'
}

is_media_active() {
    dumpsys media_session 2>/dev/null | grep -Eq 'state=PlaybackState \{state=(PLAYING|BUFFERING)'
}

is_high_accuracy_location_active() {
    dumpsys location 2>/dev/null \
        | awk '/^  Location Providers:/{seen=1} seen && /^  Historical Aggregate Location Provider Data:/{exit} seen{print}' \
        | grep 'service: ProviderRequest' \
        | grep -v 'ProviderRequest\[OFF\]' \
        | grep -Eq 'HIGH_ACCURACY|PRIORITY_HIGH_ACCURACY'
}

write_cpu_min() {
    desired="$1"
    reason="$2"
    [ -w "$CPU_POLICY/scaling_min_freq" ] || return 1
    current=$(read_one_line "$CPU_POLICY/scaling_min_freq")
    [ "$current" = "$desired" ] && return 0
    max=$(read_one_line "$CPU_POLICY/scaling_max_freq")
    valid_frequency "$desired" || return 1
    valid_frequency "$max" || return 1
    [ "$desired" -le "$max" ] || return 1
    printf '%s' "$desired" > "$CPU_POLICY/scaling_min_freq" 2>/dev/null || return 1
    log_message "policy0 minimum $current -> $(read_one_line "$CPU_POLICY/scaling_min_freq") ($reason)"
}

apply_cpu_idle() {
    last=$(read_one_line "$LAST_CPU_STATE")
    [ "$last" = idle ] && return 0
    write_cpu_min "$CPU_TARGET" screen-off-idle || return 1
    printf '%s\n' idle > "$LAST_CPU_STATE"
}

restore_cpu() {
    last=$(read_one_line "$LAST_CPU_STATE")
    current=$(read_one_line "$CPU_POLICY/scaling_min_freq")
    original=$(read_one_line "$ORIGINAL_CPU_MIN")
    if [ "$current" = "$CPU_TARGET" ] && valid_frequency "$original"; then
        write_cpu_min "$original" active-policy || return 1
    fi
    [ "$last" = active ] || printf '%s\n' active > "$LAST_CPU_STATE"
}

apply_activity_guard() {
    last=$(read_one_line "$LAST_ACTIVITY_STATE")
    [ "$last" = guarded ] && return 0
    current=$(read_uid_appop)
    if [ "$current" != ignore ]; then
        cmd appops set --uid "$GMS_PACKAGE" "$ACTIVITY_OP" ignore >/dev/null 2>&1
        after=$(read_uid_appop)
        if [ "$after" = ignore ]; then
            log_message "GMS UID activity guard applied: $current -> ignore"
        else
            log_message "WARNING: failed to apply GMS UID activity guard; readback=$after"
            return 1
        fi
    fi
    printf '%s\n' guarded > "$LAST_ACTIVITY_STATE"
}

restore_activity_guard() {
    last=$(read_one_line "$LAST_ACTIVITY_STATE")
    [ "$last" = active ] && return 0
    original_uid=$(read_one_line "$ORIGINAL_ACTIVITY_UID")
    original_package=$(read_one_line "$ORIGINAL_ACTIVITY_PACKAGE")
    valid_appop_mode "$original_uid" || original_uid=allow
    valid_appop_mode "$original_package" || original_package=allow

    current=$(read_uid_appop)
    if [ "$current" != "$original_uid" ]; then
        cmd appops set --uid "$GMS_PACKAGE" "$ACTIVITY_OP" "$original_uid" >/dev/null 2>&1
        log_message "GMS UID activity guard restored: $current -> $(read_uid_appop)"
    fi
    current=$(read_package_appop)
    if [ "$current" != "$original_package" ]; then
        cmd appops set --user 0 "$GMS_PACKAGE" "$ACTIVITY_OP" "$original_package" >/dev/null 2>&1
        log_message "GMS package activity app-op restored: $current -> $(read_package_appop)"
    fi
    printf '%s\n' active > "$LAST_ACTIVITY_STATE"
}

sync_profile() {
    # Activity-recognition app-op control was removed in v0.1.1. It did not
    # provide a measurable advantage and can interfere with services that use
    # Google Play services motion context. Keep the saved stock mode active.
    restore_activity_guard

    # The adaptive policy0 floor was retired in v0.1.8. The ROM restored its
    # 691.2 MHz PowerHAL baseline after our transition write, and the long-idle
    # measurement was already efficient at that stock value. Restore any
    # value left by v0.1.7 once, then leave CPU policy entirely to the ROM.
    restore_cpu
}

restore_all() {
    restore_cpu
    restore_activity_guard

    original=$(read_one_line "$ORIGINAL_LPM")
    if valid_lpm_value "$original" && [ -w "$LPM_TARGET" ]; then
        printf '%s\n' "$original" > "$LPM_TARGET" 2>/dev/null
        log_message "Restored Qualcomm LPM baseline=$original"
    fi

    original=$(read_one_line "$ORIGINAL_MOBILE_DATA")
    if valid_binary_value "$original"; then
        settings put global mobile_data_always_on "$original" 2>/dev/null
        log_message "Restored mobile_data_always_on baseline=$original"
    fi

    original=$(read_one_line "$ORIGINAL_DOZE_CONSTANTS")
    if [ "$original" = "$DOZE_ABSENT" ]; then
        settings delete global device_idle_constants >/dev/null 2>&1
        log_message "Restored device_idle_constants baseline=absent"
    elif [ -n "$original" ]; then
        settings put global device_idle_constants "$original" 2>/dev/null
        log_message "Restored device_idle_constants baseline=$original"
    fi

    original=$(read_one_line "$ORIGINAL_BLUETOOTH_SCAN_TIMEOUT")
    if [ "$original" = "$BLUETOOTH_CONFIG_ABSENT" ]; then
        device_config delete bluetooth scan_timeout_millis >/dev/null 2>&1
        log_message "Restored Bluetooth scan-timeout baseline=absent"
    elif valid_scan_timeout "$original"; then
        device_config put bluetooth scan_timeout_millis "$original" >/dev/null 2>&1
        log_message "Restored Bluetooth scan-timeout baseline=${original}ms"
    fi
}

print_status() {
    printf 'module=spacewar-daily-profile\n'
    printf 'sleep_disabled=%s (original=%s)\n' "$(read_one_line "$LPM_TARGET")" "$(read_one_line "$ORIGINAL_LPM")"
    printf 'mobile_data_always_on=%s (original=%s)\n' "$(settings get global mobile_data_always_on 2>/dev/null)" "$(read_one_line "$ORIGINAL_MOBILE_DATA")"
    printf 'device_idle_constants=%s\n' "$(settings get global device_idle_constants 2>/dev/null)"
    printf 'device_idle_constants_original=%s\n' "$(read_one_line "$ORIGINAL_DOZE_CONSTANTS")"
    printf 'bluetooth_scan_timeout_ms=%s (target=%s original=%s)\n' "$(device_config get bluetooth scan_timeout_millis 2>/dev/null)" "$BLUETOOTH_SCAN_TIMEOUT_TARGET" "$(read_one_line "$ORIGINAL_BLUETOOTH_SCAN_TIMEOUT")"
    printf 'policy0_min=%s (managed=no original=%s)\n' "$(read_one_line "$CPU_POLICY/scaling_min_freq")" "$(read_one_line "$ORIGINAL_CPU_MIN")"
    printf 'gms_activity_package=%s (original=%s)\n' "$(read_package_appop)" "$(read_one_line "$ORIGINAL_ACTIVITY_PACKAGE")"
    printf 'gms_activity_uid=%s (original=%s state=%s)\n' "$(read_uid_appop)" "$(read_one_line "$ORIGINAL_ACTIVITY_UID")" "$(read_one_line "$LAST_ACTIVITY_STATE")"
    if is_screen_on; then printf 'screen_on=yes\n'; else printf 'screen_on=no\n'; fi
    if is_charging_sysfs; then printf 'charging=yes\n'; else printf 'charging=no\n'; fi
    if is_media_active; then printf 'media_active=yes\n'; else printf 'media_active=no\n'; fi
    if is_high_accuracy_location_active; then printf 'high_accuracy_location=yes\n'; else printf 'high_accuracy_location=no\n'; fi
}

collect_diagnostics() {
    tmp="$DIAGNOSTICS.tmp"
    diag_prefix="$MODDIR/.diagnostics.$$"
    thermal_file="$diag_prefix.thermal"
    hint_file="$diag_prefix.hint"
    activity_file="$diag_prefix.activity"
    sf_file="$diag_prefix.sf"
    display_file="$diag_prefix.display"
    telephony_file="$diag_prefix.telephony"

    dumpsys thermalservice > "$thermal_file" 2>/dev/null
    dumpsys performance_hint > "$hint_file" 2>/dev/null
    dumpsys activity > "$activity_file" 2>/dev/null
    dumpsys SurfaceFlinger > "$sf_file" 2>/dev/null
    dumpsys display > "$display_file" 2>/dev/null
    # The telephony registry permits UID 2000 binder access on this ROM while
    # KernelSU's root SELinux context can receive an empty dump.
    su 2000 -c 'dumpsys telephony.registry' > "$telephony_file" 2>/dev/null

    {
        printf 'Spacewar Daily Profile diagnostics\n'
        printf 'generated=%s\n' "$(date -Ins 2>/dev/null || date)"
        module_version=$(sed -n 's/^version=//p' "$MODDIR/module.prop" | head -n 1)
        printf 'module_version=%s\n' "${module_version:-unknown}"
        printf 'android_release=%s\n' "$(getprop ro.build.version.release)"
        printf 'security_patch=%s\n' "$(getprop ro.build.version.security_patch)"
        printf 'kernel=%s\n' "$(uname -r)"
        printf 'page_size=%s\n' "$(getconf PAGE_SIZE 2>/dev/null)"
        printf '\n[profile]\n'
        print_status

        printf '\n[android16_platform]\n'
        printf 'thermal_status=%s\n' "$(sed -n 's/^Thermal Status: //p' "$thermal_file" | head -n 1)"
        printf 'thermal_hal_ready=%s\n' "$(sed -n 's/^HAL Ready: //p' "$thermal_file" | head -n 1)"
        printf 'hint_session_support=%s\n' "$(sed -n 's/^Hint Session Support: //p' "$hint_file" | head -n 1)"
        printf 'cpu_headroom_support=%s\n' "$(sed -n 's/^CPU Headroom Supported: //p' "$hint_file" | head -n 1)"
        printf 'gpu_headroom_support=%s\n' "$(sed -n 's/^GPU Headroom Supported: //p' "$hint_file" | head -n 1)"
        printf 'cached_app_freezer=%s\n' "$(sed -n 's/^[[:space:]]*use_freezer=//p' "$activity_file" | head -n 1)"
        printf 'apps_frozen=%s\n' "$(sed -n 's/^[[:space:]]*Apps frozen: //p' "$activity_file" | head -n 1)"
        if [ -r /sys/kernel/mm/lru_gen/enabled ]; then
            printf 'mglru=%s\n' "$(read_one_line /sys/kernel/mm/lru_gen/enabled)"
        else
            printf 'mglru=unsupported_by_kernel\n'
        fi

        printf '\n[memory]\n'
        printf 'mem_available_kb=%s\n' "$(awk '/^MemAvailable:/{print $2}' /proc/meminfo 2>/dev/null)"
        printf 'swap_total_kb=%s\n' "$(awk '/^SwapTotal:/{print $2}' /proc/meminfo 2>/dev/null)"
        printf 'swap_free_kb=%s\n' "$(awk '/^SwapFree:/{print $2}' /proc/meminfo 2>/dev/null)"
        if [ -r /sys/block/zram0/comp_algorithm ]; then
            printf 'zram_algorithm=%s\n' "$(read_one_line /sys/block/zram0/comp_algorithm)"
            printf 'zram_disksize_bytes=%s\n' "$(read_one_line /sys/block/zram0/disksize)"
            printf 'zram_mm_stat=%s\n' "$(read_one_line /sys/block/zram0/mm_stat)"
        fi
        printf 'memory_psi=%s\n' "$(tr '\n' ';' < /proc/pressure/memory 2>/dev/null)"
        printf 'io_psi=%s\n' "$(tr '\n' ';' < /proc/pressure/io 2>/dev/null)"

        printf '\n[display]\n'
        printf 'min_refresh_rate=%s\n' "$(settings get system min_refresh_rate 2>/dev/null)"
        printf 'peak_refresh_rate=%s\n' "$(settings get system peak_refresh_rate 2>/dev/null)"
        printf 'active_panel_hz=%s\n' "$(sed -n 's/.*activeMode=.*vsyncRate=\([0-9.]*\) Hz.*/\1/p' "$sf_file" | head -n 1)"
        printf 'display_policy=%s\n' "$(sed -n 's/.*displayManagerPolicy=//p' "$sf_file" | head -n 1)"
        printf 'idle_refresh_config=%s\n' "$(sed -n 's/.*idleScreenRefreshRateConfig=\([^}]*\).*/\1/p' "$display_file" | head -n 1)"

        printf '\n[radio]\n'
        printf 'preferred_network_mode=%s\n' "$(settings get global preferred_network_mode 2>/dev/null)"
        printf 'telephony_display=%s\n' "$(sed -n 's/^[[:space:]]*mTelephonyDisplayInfo=//p' "$telephony_file" | tail -n 1)"
        printf 'physical_channels=%s\n' "$(sed -n 's/^[[:space:]]*mPhysicalChannelConfigs=//p' "$telephony_file" | tail -n 1)"

        printf '\n[art]\n'
        dumpsys jobscheduler 2>/dev/null \
            | awk '/BackgroundDexoptJobService/{seen=1} seen && /Last successful run:/{sub(/^[[:space:]]*/, ""); print "background_dexopt_" $0; exit}'

        printf '\n[known_rom_gaps]\n'
        [ "$(sed -n 's/^HAL Ready: //p' "$thermal_file" | head -n 1)" = true ] \
            && printf 'thermal_hal_gap=no\n' || printf 'thermal_hal_gap=yes\n'
        [ "$(sed -n 's/^Hint Session Support: //p' "$hint_file" | head -n 1)" = true ] \
            && printf 'adpf_hint_gap=no\n' || printf 'adpf_hint_gap=yes\n'
        grep -q 'idleScreenRefreshRateConfig=null' "$display_file" \
            && printf 'idle_refresh_policy_gap=yes\n' || printf 'idle_refresh_policy_gap=no\n'
    } > "$tmp"

    rm -f "$thermal_file" "$hint_file" "$activity_file" "$sf_file" "$display_file" "$telephony_file"
    mv -f "$tmp" "$DIAGNOSTICS"
    chmod 0644 "$DIAGNOSTICS" 2>/dev/null
    log_message "Collected one-shot Android 16 platform diagnostics."
}
