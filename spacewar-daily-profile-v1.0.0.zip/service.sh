#!/system/bin/sh

MODDIR="${0%/*}"
. "$MODDIR/common.sh"

rm -f "$STOPFILE" "$LAST_CPU_STATE" "$LAST_ACTIVITY_STATE"

waited=0
while [ "$(getprop sys.boot_completed 2>/dev/null)" != 1 ] && [ "$waited" -lt 180 ]; do
    sleep 1
    waited=$((waited + 1))
done

if [ "$(getprop sys.boot_completed 2>/dev/null)" != 1 ]; then
    log_message "Boot wait timed out; profile not started."
    exit 0
fi

sleep 30
save_baselines
sync_profile
apply_static_profile
log_message "Started v1.0.0 stable; measured power policies unchanged. Application buckets, device-idle whitelists, notification channels, audio, CPU, GPU and memory policy are untouched."

# Bluetooth DeviceConfig is synchronized again after the first user unlock on
# this ROM. Wait for unlock, reapply once two minutes later, then verify once
# ten minutes later. The service exits after that: no permanent polling loop.
while [ ! -e "$STOPFILE" ] && ! is_user_unlocked; do
    sleep 30
done

if [ -e "$STOPFILE" ]; then
    rm -f "$STOPFILE"
    log_message "Stop requested before post-unlock verification; exited."
    exit 0
fi

sleep 120
[ -e "$STOPFILE" ] && rm -f "$STOPFILE" && log_message "Stop requested; exited." && exit 0
apply_bluetooth_scan_timeout
log_message "Completed post-unlock Bluetooth scan-timeout application."

sleep 600
[ -e "$STOPFILE" ] && rm -f "$STOPFILE" && log_message "Stop requested; exited." && exit 0
apply_bluetooth_scan_timeout
log_message "Completed one-time late Bluetooth scan-timeout verification; steady-state service exited with no polling loop."
