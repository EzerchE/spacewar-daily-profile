Spacewar Daily Profile 1.0.0

Purpose
- Consolidates the three measured daily optimizations into one KernelSU module.
- Preserves Bluetooth audio, ViPER4Android, notification channels, Tile, Home
  Assistant, Tuya, location mode and all unrelated application standby policies.

Applied policies
1. Enables the Qualcomm kernel low-power states exposed by sleep_disabled=N.
2. Allows mobile radio idle by setting mobile_data_always_on=0.
3. Restores AOSP deep-Doze entry timings (30-minute inactive/after-inactive,
   4-minute sensing, 10-minute motion-inactive) while preserving the existing
   AOSP-compatible Light Doze timings.
4. Limits filtered high-power BLE scan requests to 120 seconds before Android's
   framework downgrades them. Tile remains running; Bluetooth audio, watch
   connectivity and notification delivery are not stopped.
   Because this ROM synchronizes Bluetooth DeviceConfig again after first user
   unlock, the value is reapplied once after 120 seconds and verified once ten
   minutes later. The service then exits and does not poll continuously.

Efficiency and safety
- No steady-state loop remains. After the one-time post-unlock Bluetooth
  application and verification, the module service exits.
- The experimental screen-off policy0 minimum was retired. crDroid's PowerHAL
  restored its own 691.2 MHz baseline, and the overnight measurement remained
  efficient at that value; the module no longer competes with ROM CPU policy.
- Existing source-module baselines are imported for correct rollback.
- Google Play services activity-recognition app-op remains at its saved stock
  value; the experimental activity guard was removed after notification tests.
- Xiaomi bucket/whitelist experiments were removed after baseline bucket 20
  delivered Xiaomi and Tuya notifications immediately without extra privileges.
- No CPU frequency, governor, scheduler, GPU, ZRAM, Bluetooth audio, notification-channel,
  app-bucket or device-idle whitelist settings are changed. The only Bluetooth
  change is the reversible framework timeout described above.
- Provides read-only, on-demand Android 16 diagnostics for Thermal HAL, ADPF hint
  sessions, cached-app freezer, ART background dexopt, MGLRU availability,
  ZRAM, PSI, real panel refresh rate and cellular RAT. Diagnostics are written
  only through the module action; they do not add boot-time work or a resident loop.
- The diagnostics intentionally report ROM/kernel gaps without attempting to
  emulate missing HALs or kernel features from a KernelSU script.

Manual action
  sh action.sh status
  sh action.sh diagnostics
  sh action.sh sync
  sh action.sh restore
  sh action.sh apply
  sh action.sh stop
