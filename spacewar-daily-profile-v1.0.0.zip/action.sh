#!/system/bin/sh

MODDIR="${0%/*}"
. "$MODDIR/common.sh"

case "${1:-diagnostics}" in
    apply)
        save_baselines
        apply_static_profile
        sync_profile
        ;;
    sync)
        save_baselines
        sync_profile
        ;;
    restore)
        restore_all
        ;;
    status)
        print_status
        ;;
    diagnostics)
        collect_diagnostics
        cat "$DIAGNOSTICS"
        ;;
    stop)
        touch "$STOPFILE"
        ;;
    *)
        echo "Usage: action.sh {apply|sync|restore|status|diagnostics|stop}"
        exit 2
        ;;
esac
