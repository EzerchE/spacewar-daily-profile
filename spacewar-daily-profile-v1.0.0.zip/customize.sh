#!/system/bin/sh

# Preserve rollback baselines across module updates. KernelSU stages an update
# in a fresh directory, so runtime files from the active version are copied
# explicitly before the next reboot.
OLDMOD=/data/adb/modules/spacewar-daily-profile

for name in \
    original_sleep_disabled \
    original_mobile_data_always_on \
    original_scaling_min_freq \
    original_activity_package_appop \
    original_activity_uid_appop \
    original_device_idle_constants \
    original_bluetooth_scan_timeout; do
    if [ -s "$OLDMOD/$name" ]; then
        cp -f "$OLDMOD/$name" "$MODPATH/$name"
    fi
done

if [ ! -s "$MODPATH/original_device_idle_constants" ]; then
    value=$(settings get global device_idle_constants 2>/dev/null | tr -d '\r\n')
    if [ -z "$value" ] || [ "$value" = null ]; then value=__ABSENT__; fi
    printf '%s\n' "$value" > "$MODPATH/original_device_idle_constants"
fi

if [ ! -s "$MODPATH/original_bluetooth_scan_timeout" ]; then
    value=$(device_config get bluetooth scan_timeout_millis 2>/dev/null | tr -d '\r\n')
    if [ -z "$value" ] || [ "$value" = null ]; then value=__ABSENT__; fi
    printf '%s\n' "$value" > "$MODPATH/original_bluetooth_scan_timeout"
fi

ui_print "- Preserved reversible Spacewar profile baselines"
